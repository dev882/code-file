﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13assignValue5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Declare and initialize the integer variable empId
            int empId = 5;

            // Print the value of empId to the console
            Console.WriteLine("Employee ID: " + empId);
            Console.ReadKey();
        }
    }
}

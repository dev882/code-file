﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignstring
{
    internal class Program
    {
        //Assign a value "Pavan" for the empName variable and print the value of empId on console
        static void Main(string[] args)
        {
            // Declare a string variable named empName and initialize it with the value "Pavan"
            string empName = "Pavan";
            // Print the value stored in the empName variable
            Console.WriteLine(empName);
            // Wait for the user to press a key before closing the console window
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1empname
{
    internal class Program
    {
        //Create any value called EmpName and print that value in the output
        static void Main(string[] args)
        {
            // Define a string variable named EmpName and assign it the value "Pavan"
            string EmpName = "Pavan";
            // Print the message along with the value of EmpName
            Console.WriteLine("Give name:" + EmpName);
            // Wait for the user to press a key before closing the console window
            Console.ReadKey();
        }
    }
}

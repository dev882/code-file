/**
 * @author JALA Academy
 * Website Reference : https://java.jalaacademy.com/java/java_basics.html

 * 3. Write a program for a Single line comment, multi-line and documentation comments.
 */
package com.jala.basics;

public class Comments {
    public static void main(String[] args) {
        System.out.println("// This is a Single line comment");
        //System.out.println("// This is a Single line comment");

        System.out.println("/* This is a Multi-line comment */");
        //System.out.println("/* This is a Multi-line comment */");

        System.out.println("/** This is a Documentation comment */");
    }
}
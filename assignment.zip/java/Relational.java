/**
 * @author JALA Academy
 *
 * 6. Program for relational operators (<,<==, >, >==)
 */
package com.jala.operators;

public class Relational {
    public static void main(String[] args) {
        int a = 15;
        int b = 10;
        System.out.println(a < b);  //less than ( < )
        System.out.println(a > b);  //greater than ( > )
        System.out.println(a <= b); //less than or equals( <= )
        System.out.println(a >= b); //greater than or equals( >= )
    }
}